
@extends('layouts.main')
@section('content')
    <h1 >Welcome to BIMA BLOG</h1>
@endsection

